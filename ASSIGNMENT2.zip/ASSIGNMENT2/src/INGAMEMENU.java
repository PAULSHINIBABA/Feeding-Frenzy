public class INGAMEMENU extends GameEngine{
    public static void main(String args[]) {
        createGame(new INGAMEMENU());
    }
    @Override
    public void update(double dt) {

    }

    @Override
    public void paintComponent() {

    }
}
