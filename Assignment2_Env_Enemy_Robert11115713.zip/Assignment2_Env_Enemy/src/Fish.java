public class Fish {
}
