public class Shark {
}
