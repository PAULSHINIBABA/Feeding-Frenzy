package Assignment2;

import java.awt.*;
import java.awt.event.*;

public class assignment2_main extends GameEngine {

    pearl pearl;
    myfish myfish;
    boom boom;
    starfish starfish;
    double score;
    double emposition_x,emposition_y;//Enemies position
    int Window_w=500,Window_h=500;//window size
    int emfish_w=15,emfish_h=15;//enemies width and enemies high
    boolean up,down,left,right,gamestart;
    Image myfish_r,myfish_l, pearlimage,boomimage,starfishimage,backgoundimage;
    // The main program that controls this game
    private Main_program mainProgram;

    // Add a MainProgram parameter to the constructor
    public assignment2_main(Main_program mainProgram) {
        this.mainProgram = mainProgram;  // Remember the main program
    }
    public void random_enemies(){
        emposition_x=rand(500);
        emposition_y=rand(500);
    }
    public void draw_enemies(){
        changeColor(white);
        drawRectangle(emposition_x,emposition_y,emfish_w,emfish_h);
    }
    public Rectangle getenemiefishRec(){
        return new Rectangle((int) emposition_x, (int) emposition_y,emfish_w,emfish_h);
    }
    public void drawboom(){
        if (boom.isvisible()){
            drawImage(boomimage,boom.boompos_x,boom.boompos_y, boom.boom_w, boom.boom_h);
        }
    }
    public void drawstarfish(){
        if (starfish.isvisible()){
            drawImage(starfishimage,starfish.starfishpos_x,starfish.starfishpos_y,starfish.starfish_w,starfish.starfish_h);
        }
    }
    public void drawmyself() {
        // Decide which image to draw based on direction
        Image currentFishImage = left ? myfish_l : myfish_r;

        // Draw the fish at its current position
        drawImage(currentFishImage, (int)myfish.mposition_x,  (int)myfish.mposition_y, myfish.myfish_w, myfish.myfish_h);
    }
    public void drawpearl(){
        if (pearl.isvisible()){
            changeColor(white);
            drawImage(pearlimage,(int)pearl.getpositionx(),(int)pearl.getpositiony(), pearl.getwidth(), pearl.getheight());
        }
    }
    public void drawbackgound(){
        saveCurrentTransform();
        drawImage(backgoundimage,0,0,Window_w,Window_h);
        restoreLastTransform();
    }
    private void gameover() {
        changeColor(white);
        clearBackground(500, 500);
        drawText(160, 150, "Game over");
        drawText(160,220,"Score: "+score);
    }

    public void init(){
        myfish=new myfish();
        pearl=new pearl();
        boom=new boom();
        starfish=new starfish();
        up=false;
        down=false;
        right=false;
        left=false;
        gamestart=true;
        score=0;

        //load image
        backgoundimage=loadImage("src/Assignment2/background.png");
        myfish_r=loadImage("src/Assignment2/myfish_r.png");
        myfish_l=loadImage("src/Assignment2/myfish_l.png");
        pearlimage=loadImage("src/Assignment2/Pearl.png");
        boomimage=loadImage("src/Assignment2/boom.png");
        starfishimage=loadImage("src/Assignment2/starfish.png");
        random_enemies();

    }
    public void update(double dt) {
        double randstar_x = rand(500);
        double randstar_y = rand(500);
        double randboom_x = rand(500);
        double randboom_y = rand(500);
        double randspeed = rand(100);
        if (gamestart) {
            myfish.updatemyfish(dt, up, down, left, right, Window_w, Window_h);
            //update pearl
            pearl.updatepearl(dt, myfish.getmyfishRec(), myfish.myfishspeed_x, myfish.myfishspeed_y, randstar_x, randstar_y);
            //update starfish
            if(starfish.updatestarfish(dt, myfish.getmyfishRec(), score, randstar_x, randstar_y, randspeed, Window_w, Window_h)){
                score+=20;
            }
            if (boom.updateboom(dt, myfish.getmyfishRec(), gamestart, randboom_x, randboom_y, randspeed, Window_w, Window_h)){
                gamestart=false;
            }
            // Check for collision with the enemy
            if (myfish.getmyfishRec().intersects(getenemiefishRec())) {
                // Increase fish size
                myfish.myfish_w += 3;
                myfish.myfish_h += 12;

                // Reset enemy position
                random_enemies();
            }
        }
    }
    public void paintComponent() {

        if (gamestart) {
            drawbackgound();
            draw_enemies();
            drawmyself();
            drawpearl();
            drawstarfish();
            drawboom();
            drawText(20,40,"Score: "+score);
        }
        else{
            changeBackgroundColor(black);
            clearBackground(Window_w,Window_h);
            gameover();
        }
    }
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_LEFT) {
            left=true;
            right=false;
        }

        if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
            right=true;
            left=false;
        }

        if (e.getKeyCode() == KeyEvent.VK_UP) {
            up=true;
        }

        if (e.getKeyCode() == KeyEvent.VK_DOWN) {
            down=true;
        }
    }
    public void keyReleased(KeyEvent e) {
        if(e.getKeyCode() == KeyEvent.VK_LEFT)  {
            left  = false;
        }
        // The user released right arrow
        if(e.getKeyCode() == KeyEvent.VK_RIGHT) {
            right = false;
        }
        // The user released up arrow
        if(e.getKeyCode() == KeyEvent.VK_UP)    {
            up    = false;
        }
        if(e.getKeyCode() == KeyEvent.VK_DOWN)    {
            down    = false;
        }
    }
}
