package Assignment2;

import javax.sound.sampled.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;

public class StartMenu extends GameEngine {
    private Clip musicClip;
    private boolean isMusicPlaying = true;
    private Main_program mainProgram;  // The main program that controls this start menu

    public StartMenu(Main_program mainProgram) {
        this.mainProgram = mainProgram;
    }


    // Image of the background
    Image background;
    Image title;

    Image MUSICbutton;

    Image[] buttonImages = new Image[6];

    // Variables for mouse click position
    int[] ButtonXPositions = {150, 300, 140, 280, 20};
    int[] ButtonYPositions = {180, 210, 280, 320, 500,};
    boolean[] ButtonClicked = {false, false, false, false, false};

    @Override
    public void mouseClicked(MouseEvent e) {
        double mouseX = e.getX();
        double mouseY = e.getY();
        for (int i = 0; i < 5; i++) {
            double ButtonX = ButtonXPositions[i];
            double ButtonY = ButtonYPositions[i];
            double radius = 50;

            if (clickButton(mouseX, mouseY, ButtonX, ButtonY, radius)) {
                if (i == 3) {
                    Timer timer = new Timer(1000, new ActionListener() {
                        // Click the Exit and wait 1 second then Exit the program
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            System.exit(0);
                        }
                    });
                    timer.setRepeats(false);
                    timer.start();
                } else {
                    ButtonClicked[i] = !ButtonClicked[i];
                }
            }
            if (i == 0 && ButtonClicked[i]) {
                mainProgram.startMainGame();
                Loading_Page loadingPage = new Loading_Page(mainProgram);
                createGame(loadingPage);

            }
            if(i == 1 && ButtonClicked[i]){
                mainProgram.startMainGame();
                Loading_Page loadingPage = new Loading_Page(mainProgram);
                createGame(loadingPage);
            }

        }
        double musicButtonX = 475;
        double musicButtonY = 475;
        double musicButtonRadius = 25;
        if (clickButton(mouseX, mouseY, musicButtonX, musicButtonY, musicButtonRadius)) {
            toggleMusic();
        }
    }
//check the mouse location
    public boolean clickButton(double mouseX, double mouseY, double buttonX, double buttonY, double radius) {
        double dx = mouseX - buttonX;
        double dy = mouseY - buttonY;
        return (dx * dx + dy * dy) <= (radius * radius);
    }
//draw background
    public void drawBackground() {
        saveCurrentTransform();
        drawImage(background, 0, 0, 500, 500);
        restoreLastTransform();
    }
//draw title
    public void drawTitle() {
        saveCurrentTransform();
        drawImage(title, 110, 0, 300, 150);
        restoreLastTransform();
    }
//draw button
    public void drawButton() {
        for (int i = 0; i < 5; i++) {
            int buttonX = ButtonXPositions[i];
            int buttonY = ButtonYPositions[i];

            drawImage(buttonImages[i], buttonX-30, buttonY - 30, 120, 50);
        }
        drawImage(MUSICbutton,450,450,50,50);
    }
//music play
    public void playMusic(){
        try {
            //import the music file
            File soundFile = new File("src/Assignment2/Music/MENU.wav");

            AudioInputStream audioIn = AudioSystem.getAudioInputStream(soundFile);
            //get the music format

            AudioFormat format = audioIn.getFormat();

            DataLine.Info info = new DataLine.Info(Clip.class, format);

            musicClip = (Clip) AudioSystem.getLine(info);

            musicClip.open(audioIn);

            musicClip.start();
        }
        catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            e.printStackTrace();
        }
    }
    //control the music play
    public void pauseMusic(){
        musicClip.stop();
    }

    @Override
    public void init() {
        background = loadImage("src/Assignment2/NEW IMAGE/B1.png");
        title = loadImage("src/Assignment2/NEW IMAGE/title.png");

        buttonImages[0] = loadImage("src/Assignment2/NEW IMAGE/StartButton.png");
        buttonImages[1] = loadImage("src/Assignment2/NEW IMAGE/TIMERACE.png");
        buttonImages[2] = loadImage("src/Assignment2/NEW IMAGE/SETTINGS.png");
        buttonImages[3] = loadImage("src/Assignment2/NEW IMAGE/QUIT.png");
        buttonImages[4] = loadImage("src/Assignment2/NEW IMAGE/HELP.png");
        MUSICbutton = loadImage("src/Assignment2/NEW IMAGE/MUSICbutton.png");

        playMusic();
    }

    public void toggleMusic() {
        if (isMusicPlaying) {
            pauseMusic();
        } else {
            playMusic();
        }
        isMusicPlaying = !isMusicPlaying;
    }

    @Override
    public void update(double dt) {

    }

    @Override
    public void paintComponent() {
        setWindowSize(500, 500);
        drawBackground();
        drawTitle();
        drawButton();
    }

    @Override
    public int width() {
        return 500; // Set the window width to 500 pixels
    }

    @Override
    public int height() {
        return 500; // Set the window height to 500 pixels
    }
}
