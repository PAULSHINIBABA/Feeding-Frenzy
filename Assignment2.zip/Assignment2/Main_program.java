package Assignment2;
public class Main_program {
    private GameEngine currentGame;

    public Main_program() {
        // Initially, the start menu is the current game
        currentGame = new StartMenu(this);  // Pass this main program to the start menu
        GameEngine.createGame(currentGame);
    }

    public void startMainGame() {
        // When the main game starts, switch the current game to assignment2_main
        currentGame = new assignment2_main(this);
        GameEngine.createGame(currentGame);
    }
    public static void main(String args[]) {
        new Main_program();
    }
}
