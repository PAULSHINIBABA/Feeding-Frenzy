package Assignment2;

import java.awt.*;
import java.util.Timer;
import java.util.TimerTask;

public class Loading_Page extends GameEngine {
    private Main_program mainProgram;

    public Loading_Page(Main_program mainProgram) {
        this.mainProgram = mainProgram;
    }
    Image loadingImage;
    Image title;

    Image[] images = new Image[3];
    int currentTips = 0;

    double progress;

    public void init() {
        loadingImage = loadImage("src/Assignment2/NEW IMAGE/B2.png");
        title = loadImage("src/Assignment2/NEW IMAGE/title.png");
        images[0] = loadImage("src/Assignment2/NEW IMAGE/Warning.png");
        images[1] = loadImage("src/Assignment2/NEW IMAGE/Tip1.png");
        images[2] = loadImage("src/Assignment2/NEW IMAGE/Tip2.png");

        // Start the timer to switch images every 2 seconds
        Timer timer = new Timer();
        timer.schedule(new SwitchImageTask(), 0, 1000);
    }

    public void drawLoadingImage() {
        saveCurrentTransform();
        drawImage(loadingImage, 0, 0, 500, 500);
        restoreLastTransform();
    }

    public void drawTitle() {
        saveCurrentTransform();
        drawImage(title, 110, 0, 300, 150);
        restoreLastTransform();
    }

    public void drawloadingBar() {
        int x = 100;
        int y = 400;
        int width = 300;
        int height = 10;

        changeColor(Color.lightGray);
        drawRectangle(x, y, width, height);

        changeColor(Color.red);
        drawSolidRectangle(x, y, (int) (width * progress), height);
    }

    public void drawCurrentImage() {
        int imageWidth = 450;
        int imageHeight = 100;
        int imageX = 25;
        int imageY = 300;

        saveCurrentTransform();
        drawImage(images[currentTips], imageX, imageY, imageWidth, imageHeight);
        restoreLastTransform();
    }

    @Override
    public void update(double dt) {
        // Loading bar speed
        progress += 0.01;
        if (progress > 1.0) {
            progress = 1.0;
        }
    }

    @Override
    public void paintComponent() {
        setWindowSize(500, 500);
        drawLoadingImage();
        drawTitle();
        drawloadingBar();
        drawCurrentImage();
    }

    @Override
    public int width() {
        return 500;
    }

    @Override
    public int height() {
        return 500;
    }

    class SwitchImageTask extends TimerTask {
        @Override
        public void run() {
            currentTips = (currentTips + 1) % (images.length - 1);
        }
    }
}
