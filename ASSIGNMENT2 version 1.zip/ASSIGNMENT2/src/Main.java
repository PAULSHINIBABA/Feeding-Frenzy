// Imports
import java.awt.event.KeyEvent;

// The main entry point for the game
public class Main extends GameEngine{

    public static void main(String args[]) {
        createGame(new Main());
    }

    public void init() {

    }

    public void update(double dt) {

    }

    public void paintComponent() {

    }

    //-------------------------------------------------------
    // Key Presses
    //-------------------------------------------------------
    public boolean rightKey;
    public boolean leftKey;
    public boolean upKey;
    public boolean downKey;
    public boolean escKey;
    public boolean shiftKey;

    // Called whenever a key is pressed
    public void keyPressed(KeyEvent e) {
        //The user pressed left arrow
        if(e.getKeyCode() == KeyEvent.VK_LEFT) { this.leftKey = true; }
        // The user pressed right arrow
        if(e.getKeyCode() == KeyEvent.VK_RIGHT) { this.rightKey = true; }
        // The user pressed up arrow
        if(e.getKeyCode() == KeyEvent.VK_UP) { this.upKey = true; }
        // The user pressed up arrow
        if(e.getKeyCode() == KeyEvent.VK_DOWN) { this.downKey = true; }
        // The user pressed ESC
        if(e.getKeyCode() == KeyEvent.VK_ESCAPE) { this.escKey = true; }
        // The user pressed shiftKey
        if(e.getKeyCode() == KeyEvent.VK_SHIFT) { this.shiftKey = true; }
    }

    // Called whenever a key is released
    public void keyReleased(KeyEvent e) {
        // The user released left arrow
        if(e.getKeyCode() == KeyEvent.VK_LEFT) { this.leftKey = false; }
        // The user released right arrow
        if(e.getKeyCode() == KeyEvent.VK_RIGHT) { this.rightKey = false; }
        // The user released up arrow
        if(e.getKeyCode() == KeyEvent.VK_UP) { this.upKey = false; }
        // The user released up arrow
        if(e.getKeyCode() == KeyEvent.VK_DOWN) { this.downKey = false; }
        // The user released ESC
        if(e.getKeyCode() == KeyEvent.VK_ESCAPE) { this.escKey = false; }
        // The user released shiftKey
        if(e.getKeyCode() == KeyEvent.VK_SHIFT) { this.shiftKey = false; }
    }

    // Process the keys pressed for each game element.
    public void processKeys() {
        if (this.leftKey) {
        }
        if (this.rightKey) {
        }
        if (this.upKey) {
        }
        if (this.downKey) {
        }
        if (this.escKey) {
        }
        if (this.shiftKey) {
        }
    }


    //-------------------------------------------------------
    // Other system related methods
    //-------------------------------------------------------

}