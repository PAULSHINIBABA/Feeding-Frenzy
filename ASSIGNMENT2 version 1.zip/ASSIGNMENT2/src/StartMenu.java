import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class StartMenu extends GameEngine {
    public static void main(String args[]) {
        createGame(new StartMenu());
    }

    // Image of the background
    Image background;
    Image title;

    // Variables for mouse click position
    int[] circleXPositions = {120, 300, 120, 300, 50};
    int[] circleYPositions = {150, 180, 300, 340, 420};
    boolean[] circleClicked = {false, false, false, false, false};

    @Override
    public void mouseClicked(MouseEvent e) {
        double mouseX = e.getX();
        double mouseY = e.getY();
        for (int i = 0; i < 5; i++) {
            double circleX = circleXPositions[i];
            double circleY = circleYPositions[i];
            double radius = 40;

            if (clickCircle(mouseX, mouseY, circleX, circleY, radius)) {
                if (i == 3) { // Check if clicked circle is the "Exit" circle
                    Timer timer = new Timer(1000, new ActionListener() {
                        // Click the Exit and wait 1 second then Exit the program
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            System.exit(0);
                        }
                    });
                    timer.setRepeats(false); // Only execute the timer once
                    timer.start();
                } else {
                    circleClicked[i] = !circleClicked[i];
                }
            }
            if (i == 0 && circleClicked[i]){
                Loading_Page loadingPage = new Loading_Page();
                createGame(loadingPage);
            }
        }
    }

    public boolean clickCircle(double mouseX, double mouseY, double circleX, double circleY, double radius) {
        double dx = mouseX - circleX;
        double dy = mouseY - circleY;
        return (dx * dx + dy * dy) <= (radius * radius);
    }

    public void drawBackground() {
        saveCurrentTransform();
        drawImage(background, 0, 0, 500, 500);
        restoreLastTransform();
    }

    public void drawTitle() {
        saveCurrentTransform();
        drawImage(title, 120, 0, 300, 150);
        restoreLastTransform();
    }

    public void drawButton() {
        for (int i = 0; i < 5; i++) {
            int circleX = circleXPositions[i];
            int circleY = circleYPositions[i];

            if (circleClicked[i]) {
                changeColor(Color.blue);
                drawSolidCircle(circleX, circleY, 40);
            } else {
                changeColor(Color.black);
                drawCircle(circleX, circleY, 40);
            }

            changeColor(Color.red);
            drawText(circleX - 30, circleY, getButtonText(i), "Segue UI", getButtonFontSize(i));
        }
    }



    public String getButtonText(int index) {
        switch (index) {
            case 0:
                return "New Game";
            case 1:
                return "Time Race";
            case 2:
                return "Game Options";
            case 3:
                return "Exit";
            case 4:
                return "Help";
            default:
                return "";
        }
    }

    public int getButtonFontSize(int index) {
        if (index == 3 || index == 4) {
            return 18;
        }
        return 16;
    }

    @Override
    public void init() {
        background = loadImage("src/NEW IMAGE/B1.png");
        title = loadImage("src/NEW IMAGE/title.png");
    }

    @Override
    public void update(double dt) {
        // Update game logic here
    }

    @Override
    public void paintComponent() {
        setWindowSize(500, 500);
        drawBackground();
        drawTitle();
        drawButton();
    }

    @Override
    public int width() {
        return 500; // Set the window width to 500 pixels
    }

    @Override
    public int height() {
        return 500; // Set the window height to 500 pixels
    }
}
